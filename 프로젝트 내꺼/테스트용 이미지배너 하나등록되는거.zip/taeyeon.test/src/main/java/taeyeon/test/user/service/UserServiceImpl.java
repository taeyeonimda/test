package taeyeon.test.user.service;

import java.util.List;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import taeyeon.test.user.dao.UserDao;
import taeyeon.test.user.domain.User;

@Service
public class UserServiceImpl implements UserService {
	@Autowired private UserDao userDao;
	
	public List<User>getUsers(){
		return userDao.getUsers();
	}
	
	public User getUser(String userId) {
		return userDao.getUser(userId);
	}
	
	public User loginUser(User user) {
		return userDao.loginUser(user);
	}
	
	public void addUser(User user) {
		userDao.addUser(user);
	}
	
	public void updateUser(User user) {
		userDao.updateUser(user);
	}

	public void deleteUser(User user) {
		userDao.deleteUser(user);
	}

	@Override
	public User serchId(User user) {
		return userDao.serchId(user);
	}

	@Override
	public User serchPw(User user) {
		return userDao.serchPw(user);
	}

	
	
}
