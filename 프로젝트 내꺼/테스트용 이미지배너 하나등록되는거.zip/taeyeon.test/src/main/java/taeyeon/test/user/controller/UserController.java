 package taeyeon.test.user.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import taeyeon.test.user.domain.User;
import taeyeon.test.user.service.MailService;
import taeyeon.test.user.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired
	private MailService mailService;
	
	@Transactional
	@RequestMapping("/userJoin")
	public String userJoin() {
		return "user/join";
	}
	@Transactional
	@RequestMapping("userJoin/join")
	@ResponseBody
	public void regUser(User user) {
		userService.addUser(user);
	}
	
	@RequestMapping("/userLogin")
	public String userLogin() {
		return "user/login";
	}
	@Transactional
	@RequestMapping("userLogin/login")
	@ResponseBody
	public boolean loginUser(User user,HttpSession session) {
		Boolean result = false;
		User memUser = userService.loginUser(user);
		String status = memUser.getUserStatus();
		
		switch(status) {
		
		case "D" : result =false;
						break;
		
		case "A" :
			if(memUser != null) {
			result =true;
			userService.loginUser(user);
			session.removeAttribute("user");
			session.setAttribute("user", user);
		}
		break;
		}
		
		return result;
	}
	
	@RequestMapping("/userLogout")
	public String userLogOut(HttpSession session, User user) {
		session.removeAttribute("user");
		session.removeAttribute("userInfo");
		return "user/logout";
	}
	
	@RequestMapping("/userInfo")
	public String userInfo(HttpSession session) {
		User user = (User)session.getAttribute("user");
		String userId = user.getUserId();
		User newUser = new User();
		newUser = userService.getUser(userId);
		session.setAttribute("userInfo", newUser);
		return "user/userInfo";
	}
	
	@Transactional
	@RequestMapping("/change")
	public String userUpdate() {
		return "user/userInfo";
	}
	
	@RequestMapping("/userInfo/chnage")
	@ResponseBody
	public void modiUser(User user) {
		userService.updateUser(user);
	}
	
	@RequestMapping("/delete")
	public String userDelete() {
		return "user/userInfo";
	}
	
	@RequestMapping("/userInfo/delete")
	@ResponseBody
	public void delUser(User user) {
		userService.deleteUser(user);
	}
	
	@RequestMapping("/serchId")
	public String userSerchId() {
		return "user/serchId";
	}
	
	@RequestMapping("/serchId/findId")
	@ResponseBody
	@Transactional
	public String findId(HttpSession session, User user) {
	String userId = "";
	
	User memUser = userService.serchId(user);
	
	userId= memUser.getUserId();
	
	System.out.println(userId);
	if(userId != "") {
		userService.serchId(user);
		userId = memUser.getUserId();
		System.out.println(userId);
	}
	return userId;
	}
	
	@RequestMapping("/serchPw")
	public String userSerchPw() {
		return "user/serchPw";
	}
	
	@RequestMapping("/serchPw/findPw")
	@ResponseBody
	@Transactional
	public String findPw(User user) {
		String userId = "";
		
		User memUser = userService.serchPw(user);
		
		userId= memUser.getUserId();
		if(userId !="") {
			user = userService.getUser(userId);
			String userEmail = user.getUserEmail();
			userService.serchPw(user);
			mailService.send(user,userEmail);
			System.out.println(user);
			userId= memUser.getUserId();
		}
		return userId;
	}
	
}
	/*
	@RequestMapping("/getUser")
	@ResponseBody
	public void getUser(HttpSession session,Model model) {
		User user = (User)session.getAttribute("user");
		String userId = user.getUserId();
		User newUser = new User();
		newUser = userService.getUser(userId);
		session.setAttribute("userInfo", newUser);
	}*/


	/*
	@RequestMapping
	@ResponseBody
	public int getUser(HttpServletRequest req) {
		String userId = req.getParameter("userId");
		User idChk = userService.getUser(userId);
		int result = 0;
		if(idChk !=null) {
			result =1;
		}else {
			result =0;
			userService.getUser(userId);
		}
		return result;
	}
*/

	/*
	
	*/
	