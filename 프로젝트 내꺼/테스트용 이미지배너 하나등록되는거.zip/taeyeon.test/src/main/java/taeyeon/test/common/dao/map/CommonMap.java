package taeyeon.test.common.dao.map;

public class CommonMap {

}
