package taeyeon.test.user.dao.map;

import java.util.List;

import taeyeon.test.user.domain.User;

public interface UserMap {
	List<User> getUsers();
	
	User loginUser(User user);
	
	User getUser(String userId);
	void addUser(User user);
	void updateUser(User user);
	void deleteUser(User user);
	
	User serchPw(User user);
	User serchId(User user);

}
