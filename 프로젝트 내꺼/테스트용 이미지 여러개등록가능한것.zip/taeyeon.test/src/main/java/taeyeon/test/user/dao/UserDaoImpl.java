package taeyeon.test.user.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import taeyeon.test.user.dao.map.UserMap;
import taeyeon.test.user.domain.User;

@Repository
public class UserDaoImpl implements UserDao{
	@Autowired private UserMap userMap;

	public List<User> getUsers(){
		return userMap.getUsers();
	}
	
	public User getUser(String userId) {
		return userMap.getUser(userId);
	}
	
	public User loginUser(User user) {
		return userMap.loginUser(user);
	}
	
	public void addUser(User user) {
		userMap.addUser(user);
	}
	
	public void deleteUser(User user) {
		userMap.deleteUser(user);
	}

	public void updateUser(User user) {
		userMap.updateUser(user);		
	}

	@Override
	public User serchId(User user) {
		return userMap.serchId(user);
	}
	
	public User serchPw(User user) {
		return userMap.serchPw(user);
	}
	

}
