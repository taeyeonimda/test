package taeyeon.test.common.service;

public class CommonService {

}
