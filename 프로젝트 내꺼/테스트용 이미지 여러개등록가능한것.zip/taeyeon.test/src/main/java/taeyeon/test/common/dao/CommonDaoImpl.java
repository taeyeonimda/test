package taeyeon.test.common.dao;

public class CommonDaoImpl {

}
