package taeyeon.test.user.service;

import taeyeon.test.user.domain.User;

public interface MailService {
	void send(User user,String userEmail);
}
