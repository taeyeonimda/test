package taeyeon.test.user.domain;

import java.sql.Date;

public class User {
	private String userId;
	private String userName;
	private String userPwd;
	private String userEmail;
	private String userTel;
	private String userAddr;
	private String userBirth;
	private Date userReg;
	private String userClass;
	private String userStatus;
	
	private String subject;
	private String content;
	private String receiver;
	
	////////////////
	
	public String getSubject() {
		return subject;
	}

	public String getContent() {
		return content;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
/////////////////////////////////
	public String getUserId() {
		return userId;
	}

	public String getUserName() {
		return userName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public String getUserTel() {
		return userTel;
	}

	public String getUserAddr() {
		return userAddr;
	}

	public String getUserBirth() {
		return userBirth;
	}

	public Date getUserReg() {
		return userReg;
	}

	public String getUserClass() {
		return userClass;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}

	public void setUserAddr(String userAddr) {
		this.userAddr = userAddr;
	}

	public void setUserBirth(String userBirth) {
		this.userBirth = userBirth;
	}

	public void setUserReg(Date userReg) {
		this.userReg = userReg;
	}

	public void setUserClass(String userClass) {
		this.userClass = userClass;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userPwd=" + userPwd + ", userEmail=" + userEmail
				+ ", userTel=" + userTel + ", userAddr=" + userAddr + ", userBirth=" + userBirth + ", userReg="
				+ userReg + ", userClass=" + userClass + ", userStatus=" + userStatus + "]";
	}

}
