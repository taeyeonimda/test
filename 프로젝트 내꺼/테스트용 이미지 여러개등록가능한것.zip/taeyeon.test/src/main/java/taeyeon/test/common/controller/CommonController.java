package taeyeon.test.common.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import taeyeon.test.user.domain.User;

@RequestMapping("common")
@Controller
public class CommonController {

	@RequestMapping("/gil")
	public String commonMain() {
		return "common/Introduce";
	}
	
	@RequestMapping("/myPage")
	public String myPage(HttpSession session) {
		User user = (User)session.getAttribute("user");
		return "common/myPage";
	}
}
