drop user hotel cascade;

create user hotel IDENTIFIED BY hotel default tablespace users;
grant connect, resource TO hotel;
