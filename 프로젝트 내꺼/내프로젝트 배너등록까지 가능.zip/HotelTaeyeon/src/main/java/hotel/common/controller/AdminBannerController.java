package hotel.common.controller;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@Controller
@RequestMapping("/admin/common")
public class AdminBannerController {
	@Value("${bannerAttachDir}")
	private String bannerAttachDir;

	@RequestMapping("/bannerRegist")
	public void bannerRegister() {
	}

	@RequestMapping(value="/bannerRegistProc",method=RequestMethod.POST)
	@ResponseBody
	public boolean bannerRegistProc(MultipartHttpServletRequest multi, 
			MultipartFile file,MultipartFile attachFile, HttpServletRequest request) {

		boolean stored = true;
		String dir = "";
		String fileName = "";

		Iterator<String> files = multi.getFileNames();
		while (files.hasNext()) {
			String uploadFile = files.next();

			file = multi.getFile(uploadFile);
			
			dir = request.getServletContext().getRealPath(bannerAttachDir);
			fileName = file.getOriginalFilename();
			String basename = FilenameUtils.getBaseName(fileName);
			try {
				file.transferTo(new File(dir +"/"+ basename+".jpg"));
	
				System.out.println("dir : " + dir);
				System.out.println("attachFile : " + attachFile);
				System.out.println("baseName :" + basename);
				System.out.println(file);
			} catch (IOException e) {
				stored = false;
			}
		} // 와일끝
		return stored;
	}
	

}