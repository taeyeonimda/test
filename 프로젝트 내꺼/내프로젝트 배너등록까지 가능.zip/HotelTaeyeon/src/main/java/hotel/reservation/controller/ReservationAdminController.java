package hotel.reservation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import hotel.reservation.domain.Reservation;
import hotel.reservation.service.ReservationService;

@Controller
@RequestMapping("/admin/reservation")
public class ReservationAdminController {
	@Autowired
	private ReservationService resService;
	
	@RequestMapping("/resList")
	public @ModelAttribute("reservations") List<Reservation> listReservations() {
		return resService.listReservations();
	}
	
	@RequestMapping("/resInfo")
	public @ModelAttribute("reservation") Reservation displayReservation(int resNum) {
		return resService.displayReservation(resNum);
	}
}
