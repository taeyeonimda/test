package hotel.reservation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import hotel.reservation.domain.Reservation;
import hotel.reservation.service.ReservationService;
import hotel.room.domain.Room;
import hotel.room.domain.RoomType;
import hotel.room.service.RoomService;

@Controller
@RequestMapping("/reservation")
public class ReservationController {
	@Autowired
	private ReservationService resService;
	
	@Autowired
	private RoomService roomService;
	
	/*
	@RequestMapping("/admin/reservation/resList")
	public @ModelAttribute("reservations") List<Reservation> listReservations() {
		return resService.listReservations();
	}
	
	@RequestMapping("../admin/reservation/resInfo")
	public @ModelAttribute("reservation") Reservation displayReservation(int resNum) {
		return resService.displayReservation(10001);
	} */
	
	@RequestMapping("../room/roomSt")
	public void displayRoom() {
		// return "../room/roomSt";
	}
	
	@RequestMapping(value="/resWrite")
	public void registerResWrite() {
		
	}
	
	@RequestMapping(value="/resPay")
	public void registerResPay(Model model, String roomTypeTxt) {
		RoomType roomType = new RoomType();
		roomType = roomService.getRoomType(roomTypeTxt);
		
		model.addAttribute("roomType", roomType);
	}
	
	@RequestMapping(value="/resInfo")
	public @ModelAttribute("reservation") Reservation displayResInfo(int resNum) {
		return resService.displayReservation(resNum);
	}

	/*
	@RequestMapping(value="/resMy")
	public void listResHist() {
		
	} */
	
	@RequestMapping("/resMy")
	public @ModelAttribute("reservations") List<Reservation> listReservations() {
		return resService.listReservations();
	}	
	
	@RequestMapping(value="registerResInfo.do", method=RequestMethod.POST)
	public String registerResInfo(@ModelAttribute("reservation") Reservation res, @ModelAttribute("room") Room room) {
		resService.registerResInfo(res);
		roomService.updateRoomResStatus(room);
		return "redirect:resMy";
	}
/*
	@RequestMapping(value="registerResPay.do", method=RequestMethod.POST)
	public String registerResPay(@ModelAttribute("reservation") Reservation res) {
		resService.registerResPay(res);
		return "redirect:resInfo";
	} */
}
