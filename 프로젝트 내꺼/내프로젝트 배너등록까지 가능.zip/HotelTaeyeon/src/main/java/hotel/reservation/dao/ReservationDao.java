package hotel.reservation.dao;

import java.util.List;

import hotel.reservation.domain.Reservation;

public interface ReservationDao {
	List<Reservation> getReservations();
	Reservation getReservation(int resNum);
	void addResInfo(Reservation res);
	void addResPay(Reservation res);
	void updateResStatus(Reservation res);
}
