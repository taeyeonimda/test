package hotel.refund.dao;

import java.util.List;

import hotel.refund.domain.Refund;

public interface RefundDao {
	List<Refund> getRefunds();
	Refund getReservation(int resNum);
	Refund getRefund(int refundNum);
	void addRefundInfo(Refund refund);
	void updateRefundStatus(Refund refund);
}
