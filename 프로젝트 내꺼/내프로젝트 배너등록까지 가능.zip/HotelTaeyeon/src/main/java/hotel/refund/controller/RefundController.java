package hotel.refund.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import hotel.refund.domain.Refund;
import hotel.refund.service.RefundService;
import hotel.reservation.domain.Reservation;
import hotel.reservation.service.ReservationService;
import hotel.room.domain.Room;
import hotel.room.service.RoomService;

@Controller
@RequestMapping("/refund")
public class RefundController {
	@Autowired
	private RefundService refundService;
	
	@Autowired
	private ReservationService resService;
	
	@Autowired
	private RoomService roomService;
	
	@RequestMapping("/refundWrite")
	public void registerRefundWrite(Model model, int resNum) {
		Reservation res = new Reservation();
		res = resService.displayReservation(resNum);
		
		model.addAttribute("res", res);
	}
	
	@RequestMapping("/refundInfo")
	public @ModelAttribute("refund")
	Refund displayRefund(Model model, int refundNum) {
		Reservation res = new Reservation();
		res = resService.displayReservation(refundNum);
		
		model.addAttribute("res", res);
		
		return refundService.displayRefund(refundNum);
	}
	
	@RequestMapping("/refundMy")
	public @ModelAttribute("refunds") List<Refund> listRefunds() {
		return refundService.listRefunds();
	}
	
	@RequestMapping(value="registerRefundInfo.do", method=RequestMethod.POST)
	public String registerRefundInfo(@ModelAttribute("reservation") Reservation res,
			@ModelAttribute("refund") Refund refund, @ModelAttribute("room") Room room) {
		resService.updateResStatus(res);
		refundService.registerRefundInfo(refund);
		roomService.updateRoomResStatus(room);
		return "redirect:refundMy";
	}
}
