package hotel.refund.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import hotel.refund.domain.Refund;
import hotel.refund.service.RefundService;
import hotel.reservation.domain.Reservation;
import hotel.reservation.service.ReservationService;
import hotel.room.domain.Room;

@Controller
@RequestMapping("/admin/refund")
public class RefundAdminController {
	@Autowired
	private RefundService refundService;
	
	@Autowired
	private ReservationService resService;
	
	@RequestMapping("/refundList")
	public @ModelAttribute("refunds") List<Refund> listrefunds() {
		return refundService.listRefunds();
	}
	
	@RequestMapping("/refundInfo")
	public @ModelAttribute("refund") Refund displayrefund(Model model, int refundNum) {
		Reservation res = new Reservation();
		res = resService.displayReservation(refundNum);
		
		model.addAttribute("res", res);
		
		return refundService.displayRefund(refundNum);
	}

	@RequestMapping(value="updateRefundStatus.do", method=RequestMethod.POST)
	public String updateRefundStatus(@ModelAttribute("refund") Refund refund) {
		refundService.updateRefundStatus(refund);
		return "redirect:refundList";
	}
}
