package hotel.refund.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import hotel.refund.dao.map.RefundMap;
import hotel.refund.domain.Refund;

@Repository
public class RefundDaoImpl implements RefundDao {
	@Autowired
	private RefundMap refundMap;
	
	@Override
	public List<Refund> getRefunds() {
		return refundMap.getRefunds();
	}

	@Override
	public Refund getReservation(int resNum) {
		return refundMap.getReservation(resNum);
	}
	
	@Override
	public Refund getRefund(int refundNum) {
		return refundMap.getRefund(refundNum);
	}
	
	@Override
	public void addRefundInfo(Refund refund) {
		refundMap.addRefundInfo(refund);
	}

	@Override
	public void updateRefundStatus(Refund refund) {
		refundMap.updateRefundStatus(refund);
	}
}
