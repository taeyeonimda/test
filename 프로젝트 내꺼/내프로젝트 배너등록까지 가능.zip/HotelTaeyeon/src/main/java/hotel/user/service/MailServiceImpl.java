package hotel.user.service;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import hotel.user.domain.User;

@Service
public class MailServiceImpl implements MailService{
	@Autowired private JavaMailSender mailSender;
	
	public void send(User user,String userEmail) {
		MimeMessage message = mailSender.createMimeMessage();
		
		String text = "<div><h2>"+user.getUserName()+"</h2>님의\n"
								+"비밀번호는<mark>"+user.getUserPwd()+"</mark>입니다</div>";
	try {
		message.addRecipient(RecipientType.TO,new InternetAddress(userEmail));
		message.setSubject("트래블 하우스");
		message.setText(text,"UTF-8","HTML");
	}catch(Exception e) {}
	
	mailSender.send(message);
	}
}
