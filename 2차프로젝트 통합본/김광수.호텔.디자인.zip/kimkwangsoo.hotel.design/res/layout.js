$(function(){
	   let path = window.location.pathname;
	   path = path.substring(0, path.lastIndexOf("/"));
	   path = path.substring(path.lastIndexOf("/"), path.length);
	   if(path == "/query" || path == "/refund" || path == "/reservation"
	   || path == "/review" || path == "/room"  || path == "/user" || path == "/map")
	   {
	      $('header').load('../common/header.html');
	      $('footer').load('../common/footer.html');
	   }else if(path == "/common") {
	      $('header').load('header.html');
	      $('footer').load('footer.html');
	   }else {
	      $('header').load('common/header.html');
	      $('footer').load('common/footer.html');
	   }
	});